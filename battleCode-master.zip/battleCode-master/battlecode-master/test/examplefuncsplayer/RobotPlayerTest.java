package examplefuncsplayer;

import static org.junit.Assert.*;
import org.junit.Test;

public class RobotPlayerTest {

	@Test
	public void testSanity() {
		assertEquals(2, 1+1);
	}

}
